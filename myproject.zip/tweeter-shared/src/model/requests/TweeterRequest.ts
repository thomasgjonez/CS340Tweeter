export interface TweeterRequest {}
