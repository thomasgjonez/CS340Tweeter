import { TweeterResponse } from "./TweeterResponse";

export interface PostStatusResponse extends TweeterResponse {}
