import { TweeterResponse } from "./TweeterResponse";

export interface LogoutUserResponse extends TweeterResponse {}
