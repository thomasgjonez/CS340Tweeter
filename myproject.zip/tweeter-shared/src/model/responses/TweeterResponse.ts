export interface TweeterResponse {
  success: boolean;
  message?: string;
}
